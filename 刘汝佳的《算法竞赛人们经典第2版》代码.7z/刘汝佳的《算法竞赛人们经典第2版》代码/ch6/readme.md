﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第六章

例题代码

6-1 UVa210 Concurrency Simulator

6-2 UVa514 Rails

6-3 UVa442 Matrix Chain Multiplication

6-4 UVa11988 Broken Keyboard

6-5 UVa12657 Boxes in a Line

6-6 UVa679 Dropping Balls

6-7 UVa122 Trees on the level

6-8 UVa548 Tree

6-9 UVa839 Not so mobile

6-10 UVa699 The Falling Leaves

6-11 UVa297 Quadtrees

6-12 UVa572 Oil Deposits

6-13 UVa1103 Ancient Messages

6-14 UVa816 Abbott's Revenge

6-15 UVa10305 Ordering Tasks

6-16 UVa10129 Play On Words

6-17 UVa10562 Undraw the Trees

6-18 UVa12171 Sculpture

6-19 UVa1572 Self-Assembly

6-20 UVa1599 Ideal Path

6-21 UVa506 System Dependencies

6-22 UVa11853 Paintball
