﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第十一章

例题代码

提交：http://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8&category=853

11-1 UVa12219 Common Subexpression Elimination

11-2 UVa1395 Slim Span

11-3 UVa1151 Buy or Build

11-4 UVa247 Calling Circles

11-5 UVa10048 Audiophobia

11-6 UVa658 It's not a Bug, it's a Feature!

11-7 UVa753 A Plug for UNIX

11-8 UVa11082 Matrix Decompressing

11-9 UVa1658 Admiral

11-10 UVa1349 Optimal Bus Route Design

11-11 UVa12661 Funny Car Racing

11-12 UVa1515 Pool construction

11-13 UVa10735 Euler Circuit

11-14 UVa1279 Asteroid Rangers

11-15 UVa1659 Help Little Laura
