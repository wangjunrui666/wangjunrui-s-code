struct Point { double x, y; };

double dist(Point a, Point b)
{
  return 0;
}

int main() {
  return 0;
}
