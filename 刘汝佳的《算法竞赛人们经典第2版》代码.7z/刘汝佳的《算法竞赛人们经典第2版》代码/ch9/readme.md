﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第九章

例题代码

9-1 UVa1025 A Spy in the Metro

9-2 UVa437 The Tower of Babylon

9-3 UVa1347 Tour

9-4 UVa116 Unidirectional TSP

9-5 UVa12563 Jin Ge Jin Qu [h]ao

9-6 UVa11400 Lighting System Design

9-7 UVa11584 Partitioning by Palindromes

9-8 UVa1625 Color Length

9-9 UVa10003 Cutting Sticks

9-10 UVa1626 Brackets Sequence

9-11 UVa1331 Minimax Triangulation

9-12 UVa12186 Another Crisis

9-13 UVa1220 Party at Hali-Bula

9-14 UVa1218 Perfect Service

9-15 UVa10817 Headmaster's Headache

9-16 UVa1252 Twenty Questions

9-17 UVa1412 Fund Management （附数据）

9-18 UVa10618 Tango Tango Insurrection

9-19 UVa1627 Team them up!

9-20 UVa10934 Dropping water balloons

9-21 UVa1336 Fixing the Great Wall

9-22 UVa12105 Bigger is Better

9-23 UVa1204 Fun Game

9-24 UVa12099 Bookcase

9-25 UVa12170 Easy Climb

9-26 UVa1380 A Scheduling Problem

9-27 UVa10559 Blocks

9-28 UVa1439 Exclusive Access 2

9-29 UVa1228 Integer Transmission

9-30 UVa1375 The Best Name for Your Baby

9-31 UVa1628 Pizza Delivery
